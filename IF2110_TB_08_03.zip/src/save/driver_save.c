#include <stdio.h>
#include "includes.c"
#include "save.h"

int main() {
    Sinfotype State;
    Graph RelasiBan;
    Matriks M;
    saveData(State, RelasiBan, M);

    return 0;
}
