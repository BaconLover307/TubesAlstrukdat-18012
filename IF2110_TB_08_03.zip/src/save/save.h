/* file : save.h */
/* header untuk melakukan save file */

#ifndef save_H
#define save_H

#include "../stackt/stackt.h"
#include "../graph/graph.h"

void saveData(Sinfotype state, Graph relasi, MATRIKS M);

#endif
